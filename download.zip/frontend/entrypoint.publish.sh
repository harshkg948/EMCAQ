#!/bin/sh

pnpm serve:dist